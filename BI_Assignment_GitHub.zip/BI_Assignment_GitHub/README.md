# Business Intelligence Analytics Project

A multi-tool Business Intelligence assignment using **Python, Power BI and Tableau**.

## Included

- Python data preparation and analysis
- Power BI-ready CSV data model and DAX measures
- Power BI Python visual script
- Tableau-ready CSV data sources
- Tableau + TabPy Python integration script
- Dashboard design screenshots / previews
- Completed Excel reference workbook
- Original supplied datasets

## Screenshots

| Tool | Sales | Employee & Training |
|---|---|---|
| Python | `screenshots/01_python_sales_dashboard.png` | `screenshots/02_python_employee_training.png` |
| Power BI | `screenshots/03_powerbi_sales_preview.png` | `screenshots/04_powerbi_employee_training_preview.png` |
| Tableau | `screenshots/05_tableau_sales_preview.png` | `screenshots/06_tableau_employee_training_preview.png` |

> The Power BI and Tableau PNGs are **dashboard design previews generated from the supplied data**, not screenshots captured from the proprietary desktop applications. The project includes the exact build guides, CSV sources, DAX, and Python/TabPy scripts needed to recreate them in Power BI Desktop and Tableau.

## Run the Python project

```bash
pip install -r requirements.txt
python scripts/main.py
```

The data is stored in `data/`, and the Python scripts are in `scripts/`.

## Power BI

See `docs/POWER_BI_GUIDE.md` and `docs/powerbi_measures.dax`.

Microsoft documents that Power BI Desktop can run Python scripts and Python visuals using pandas and Matplotlib.  
Official documentation: https://learn.microsoft.com/en-us/power-bi/connect-data/desktop-python-scripts

## Tableau

See `docs/TABLEAU_GUIDE.md` and `scripts/tableau_tabpy.py`.

Tableau supports Python through analytics extensions such as TabPy.  
Official documentation: https://help.tableau.com/current/pro/desktop/en-us/r_connection_manage.htm

## Data summary

- TrainingData1: 15,000 rows
- TrainingSample2: 60,919 rows
- Date Master: 2,557 rows
- Employees: 50
- Workshop records: 152

## Repository structure

```text
BI_Assignment_GitHub/
├── data/
├── docs/
├── scripts/
├── screenshots/
├── Business_Intelligence_Assignment_Completed.xlsx
├── requirements.txt
└── README.md
```
