# Power BI Build Guide

## Data
Use the CSV files in `data/`:
- `sales_clean.csv`
- `training_sample2_clean.csv`
- `date_master_clean.csv`
- `employee_master_clean.csv`
- `workshops_clean.csv`

## Sales page
Create KPI cards for:
- Total Sales
- Total Profit
- Total Orders
- Units Sold
- Profit Margin

Create:
1. Line chart: Month → Total Sales, Legend → Region
2. Bar chart: Region → Total Sales
3. Column chart: Product Category → Total Sales
4. Donut chart: Channel → Total Sales
5. Slicers: Year, Region, Channel, Product Category

## Employee / Training page
Create:
1. KPI cards: Employees, Employees Trained, Training Cost, Average Salary
2. Bar chart: Dept → Employee count
3. Column chart: Year → Training Cost
4. Pie/donut: Gender → Employee count
5. Column chart: Job Grade → Employee count

## Python visual
Use `scripts/powerbi_python_visual.py` in a Power BI Python visual. Power BI's Python integration expects Python to be installed locally and supports pandas/matplotlib for Python visuals.
