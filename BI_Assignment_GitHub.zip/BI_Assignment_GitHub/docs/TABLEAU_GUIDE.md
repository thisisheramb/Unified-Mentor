# Tableau Build Guide

## Connect
Open Tableau Desktop → Connect → Text File, then select:
- `data/sales_clean.csv`
- `data/employee_master.csv`
- `data/workshops_clean.csv`
- `data/date_master_clean.csv`

## Sales dashboard
Sheets:
- Sales Trend: Order Date (month) + SUM(Sales), Region on Color
- Regional Sales: Region + SUM(Sales)
- Category Sales: Product Category + SUM(Sales)
- Channel Share: Channel + SUM(Sales)

Dashboard filters:
- Year
- Region
- Channel
- Product Category

## People & Training dashboard
Sheets:
- Employees by Department
- Training Cost by Year
- Gender Mix
- Job Grade Mix

## Python integration
Install TabPy:
    pip install tabpy

Start:
    tabpy

Then connect Tableau to localhost:9004 and use `scripts/tableau_tabpy.py`.
