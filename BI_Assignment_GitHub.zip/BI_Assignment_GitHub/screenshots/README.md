# Dashboard Screenshots

## Python
- `01_python_sales_dashboard.png`
- `02_python_employee_training.png`

## Power BI
- `03_powerbi_sales_preview.png`
- `04_powerbi_employee_training_preview.png`

## Tableau
- `05_tableau_sales_preview.png`
- `06_tableau_employee_training_preview.png`

The Power BI/Tableau images are implementation previews generated from the same source data. Use the included build guides to recreate them in the applications.
