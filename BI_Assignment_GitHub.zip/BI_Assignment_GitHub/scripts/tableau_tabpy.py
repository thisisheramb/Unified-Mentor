"""
Tableau + TabPy example.

Install:
    pip install tabpy pandas
Start:
    tabpy

In Tableau:
    Analytics > Manage Analytics Extensions Connections
    Select TabPy
    Host: localhost
    Port: 9004

The function below can be called from a Tableau calculated field.
"""

import pandas as pd

def sales_growth(sales):
    s = pd.Series(sales).astype(float)
    if len(s) < 2:
        return [0.0] * len(s)
    prev = s.shift(1)
    growth = ((s - prev) / prev.replace(0, pd.NA) * 100).fillna(0)
    return growth.tolist()
