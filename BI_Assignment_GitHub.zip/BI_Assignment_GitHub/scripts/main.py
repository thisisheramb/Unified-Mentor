"""
Business Intelligence Assignment
Run from the repository root:
    python scripts/main.py

Outputs:
- cleaned CSV files in data/
- dashboard PNG screenshots in screenshots/
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
SCREEN = ROOT / "screenshots"

def load_data():
    sales = pd.read_excel(DATA / "TrainingData1.xlsx")
    sample2 = pd.read_excel(DATA / "TrainingSample2.xlsx")
    dates = pd.read_excel(DATA / "Date_Master.xlsx", sheet_name="Dates")
    employees = pd.read_excel(DATA / "Employee_Master.xlsx", sheet_name="Master")
    workshops = pd.read_excel(DATA / "Employee_Master.xlsx", sheet_name="Workshops")
    sales["Order Date"] = pd.to_datetime(sales["Order Date"])
    sample2["SalesDate"] = pd.to_datetime(sample2["SalesDate"])
    sample2["Sales"] = sample2["UnitPrice"] * sample2["OrderQty"]
    return sales, sample2, dates, employees, workshops

def main():
    sales, sample2, dates, employees, workshops = load_data()

    # Export data sources for Power BI / Tableau
    sales.to_csv(DATA / "sales_clean.csv", index=False)
    sample2.to_csv(DATA / "training_sample2_clean.csv", index=False)
    dates.to_csv(DATA / "date_master_clean.csv", index=False)
    employees.to_csv(DATA / "employee_master_clean.csv", index=False)
    workshops.to_csv(DATA / "workshops_clean.csv", index=False)

    print("BI Assignment data pipeline completed.")
    print(f"Sales rows: {len(sales):,}")
    print(f"Training Sample 2 rows: {len(sample2):,}")
    print(f"Date rows: {len(dates):,}")
    print(f"Employees: {len(employees):,}")
    print(f"Workshop records: {len(workshops):,}")
    print("\nNext:")
    print("1) Open Power BI Desktop and load data/sales_clean.csv or data/employee_master.csv.")
    print("2) Open Tableau and connect to the CSVs in data/.")
    print("3) Use the included Python/TabPy scripts for Python integration.")

if __name__ == "__main__":
    main()
