# Power BI Python visual
# Add the fields: Region, Order Date, Sales
# Power BI supplies the selected data as the dataframe named `dataset`.

import pandas as pd
import matplotlib.pyplot as plt

df = dataset.copy()
df["Order Date"] = pd.to_datetime(df["Order Date"])
monthly = (
    df.assign(Month=df["Order Date"].dt.to_period("M").astype(str))
      .groupby(["Month", "Region"], as_index=False)["Sales"].sum()
)

pivot = monthly.pivot(index="Month", columns="Region", values="Sales").fillna(0)

ax = pivot.plot(figsize=(10, 5), linewidth=2)
ax.set_title("Monthly Sales by Region")
ax.set_xlabel("Month")
ax.set_ylabel("Sales ($)")
plt.xticks(rotation=60)
plt.tight_layout()
plt.show()
