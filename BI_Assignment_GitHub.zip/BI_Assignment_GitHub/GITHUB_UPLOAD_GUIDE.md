# GitHub Upload

1. Extract `BI_Assignment_GitHub.zip`.
2. Create a new GitHub repository.
3. Upload the extracted folder contents.
4. Keep `README.md` at the repository root.
5. Put screenshots under `screenshots/`.
6. Put source data under `data/`.
7. Put Python files under `scripts/`.

Suggested repository name:

`business-intelligence-python-powerbi-tableau`

Recommended GitHub description:

`Business Intelligence project using Python, Power BI and Tableau with sales, employee and training analytics.`
